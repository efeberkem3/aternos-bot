## Aternos Sunucularınız İçin 7/24 Bot!

## 📑 Bot Özellikleri

- [x] Hareket Etme
- [x] Sürüm Değiştirme
- [x] Koordinata Gitme
- [x] Giriş Komutlarını Yürütme
- [x] Hit Atma (Yaratıkları Öldürme)
- [x] Sohbete Gelen Mesajları Okuma
- [x] Sohbete Mesaj Gönderme

## Bot Ayarları

settings.json dosyasından aşağıdaki adımları takip edin:

- Satır 3. username bölümüne botunuzun kullanıcı adını girin. (Türkçe harf ve boşluk kullanmayın!)
- Satır 7. ip yerine sunucunuzun IP adresini yazın. (Örnek: KylusTest.aternos.me) (Port'u bu bölüme girmeyin!)
- Satır 8. port bölümüne sunucunuzun Port'unu girin. (Örnek: 29483)
- Satır 9. version bölümüne sunucunuzun sürümünü girin. (Sürüm ne kadar yükselir ise, botunuza o kadar yük biner.) (Alt sürümler tavsiye edilir.)
- Satır 20. Sunucunuzda giriş eklentisi varsa (AuthMe, NLogin vb.) Satır 21. enabled ayarını true yapın, Satır 22. password bölümüne şifreyi girin. (Türkçe harf ve boşluk kullanmanız önerilmez.) 

## Destek Almak İçin Ne Yapmalıyım?

- [Bu adresten](https://discord.gg/youtube-kylus-1-4k-1069319803963195402) Discord sunucumuza katılabilirsiniz.
